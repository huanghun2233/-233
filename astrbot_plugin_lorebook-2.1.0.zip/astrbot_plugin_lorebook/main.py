"""世界书插件 v2（astrbot_plugin_lorebook）

融合两条路线：
  - 酒馆 World Info 的触发语义（关键词 / 次要词逻辑 / 概率 / 位置 / 深度 / 预算）
  - 参考实现的多规则分发（YAML 存储、6 种模板、cron 定时、定向用户/群、状态机）

四层结构：
  1. 存储与模型层：YAML 为主，兼容酒馆 v2 JSON；统一抽象成 LoreEntry
  2. 触发与过滤管线：黑白名单 → 多源触发器（关键词/正则/cron/定向）→ 冷却与持续状态机
  3. 动态自治层：LLM 工具写条目，但只落到「待审核区」，管理员批准后才生效
  4. 注入层：按 position/depth 拼进 system_prompt 或 contexts
"""

import json
import math
import random
import re
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

import yaml

from astrbot.api import logger
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Context, Star, register

NL = chr(10)

POS_MAP = {
    "before": 0, "after": 1, "an_top": 2, "an_bottom": 3,
    "at_depth": 4, "em_top": 5, "em_bottom": 6,
    "0": 0, "1": 1, "2": 2, "3": 3, "4": 4, "5": 5, "6": 6,
}
LOGIC_MAP = {
    "any": 0, "and_any": 0, "not_all": 1, "not_any": 2, "all": 3, "and_all": 3,
    "0": 0, "1": 1, "2": 2, "3": 3,
}
TEMPLATES = ("common", "resident", "chance", "schedule", "user", "group")

DEFAULTS = {
    "worldsDir": "",
    "activeWorlds": [],
    "groupBindings": {},
    "scanDepth": 4,
    "budgetChars": 2000,
    "caseSensitive": False,
    "matchWholeWords": False,
    "recursive": False,
    "maxRecursionSteps": 0,
    "cronWindowSeconds": 90,
    "selfWriteEnabled": True,      # 允许 LLM 往待审核区写条目
    "adminOnly": True,
    "debugLog": False,
}


# --------------------------------------------------------------------------- #
# cron（5 段：分 时 日 月 周）
# --------------------------------------------------------------------------- #
def _field_match(spec: str, lo: int, hi: int, value: int) -> bool:
    for part in spec.split(","):
        part = part.strip()
        if not part:
            continue
        step = 1
        if "/" in part:
            part, s = part.split("/", 1)
            try:
                step = max(1, int(s))
            except ValueError:
                step = 1
        if part in ("*", "?"):
            start, end = lo, hi
        elif "-" in part:
            a, b = part.split("-", 1)
            try:
                start, end = int(a), int(b)
            except ValueError:
                continue
        else:
            try:
                start = end = int(part)
            except ValueError:
                continue
        if start <= value <= end and (value - start) % step == 0:
            return True
    return False


def cron_match(expr: str, dt: datetime) -> bool:
    parts = (expr or "").split()
    if len(parts) != 5:
        return False
    values = [dt.minute, dt.hour, dt.day, dt.month, (dt.weekday() + 1) % 7]
    bounds = [(0, 59), (0, 23), (1, 31), (1, 12), (0, 6)]
    return all(_field_match(p, lo, hi, v) for p, (lo, hi), v in zip(parts, bounds, values))


# --------------------------------------------------------------------------- #
# 条目
# --------------------------------------------------------------------------- #
@dataclass
class LoreEntry:
    uid: int = 0
    name: str = ""
    template: str = "common"
    content: str = ""
    # 触发
    keys: list = field(default_factory=list)
    secondary: list = field(default_factory=list)
    logic: int = 0
    regex: list = field(default_factory=list)
    constant: bool = False
    probability: int = 100
    cron: str = ""
    users: list = field(default_factory=list)
    groups: list = field(default_factory=list)
    # 位置
    position: int = 0
    depth: int = 4
    order: int = 100
    weight: float = 1.0
    # 状态
    turns: int = 0
    cooldown: int = 0
    decay_minutes: int = 0
    exclusive_group: str = ""
    disable: bool = False
    # 来源
    source: str = "file"

    @property
    def label(self) -> str:
        return self.name or (self.keys[0] if self.keys else f"#{self.uid}")

    @classmethod
    def from_any(cls, raw: dict, uid: int = 0, source: str = "file") -> "LoreEntry":
        """同时吃 YAML 友好字段和酒馆 v2 字段"""
        def as_list(v):
            if v is None:
                return []
            if isinstance(v, str):
                return [v] if v.strip() else []
            return [str(x) for x in v if str(x).strip()]

        def as_int(v, default=0):
            try:
                return int(v)
            except (TypeError, ValueError):
                return default

        def as_float(v, default=1.0):
            try:
                return float(v)
            except (TypeError, ValueError):
                return default

        pos = raw.get("position", "before")
        position = POS_MAP.get(str(pos).lower(), as_int(pos, 0))
        logic = LOGIC_MAP.get(str(raw.get("logic", raw.get("selectiveLogic", 0))).lower(), 0)

        e = cls(
            uid=as_int(raw.get("uid"), uid),
            name=str(raw.get("name") or raw.get("comment") or ""),
            template=str(raw.get("template") or "common").lower(),
            content=str(raw.get("content") or ""),
            keys=as_list(raw.get("keys") or raw.get("key")),
            secondary=as_list(raw.get("secondary") or raw.get("keysecondary")),
            logic=logic,
            regex=as_list(raw.get("regex")),
            constant=bool(raw.get("constant", False)),
            probability=as_int(raw.get("probability"), 100),
            cron=str(raw.get("cron") or ""),
            users=as_list(raw.get("users")),
            groups=as_list(raw.get("groups")),
            position=position,
            depth=as_int(raw.get("depth"), 4),
            order=as_int(raw.get("order"), 100),
            weight=as_float(raw.get("weight"), 1.0),
            turns=as_int(raw.get("turns"), 0),
            cooldown=as_int(raw.get("cooldown"), 0),
            decay_minutes=as_int(raw.get("decay_minutes"), 0),
            exclusive_group=str(raw.get("exclusive_group") or raw.get("group") or ""),
            disable=bool(raw.get("disable", False)),
            source=source,
        )
        # 模板只是语法糖，落到同一套字段
        if e.template == "resident":
            e.constant = True
        elif e.template == "chance":
            if e.probability >= 100:
                e.probability = 50
        elif e.template == "schedule":
            e.constant = False
        if e.template not in TEMPLATES:
            e.template = "common"
        return e

    def to_dict(self) -> dict:
        return {
            "name": self.name, "template": self.template, "content": self.content,
            "keys": self.keys, "secondary": self.secondary, "logic": self.logic,
            "regex": self.regex, "constant": self.constant, "probability": self.probability,
            "cron": self.cron, "users": self.users, "groups": self.groups,
            "position": self.position, "depth": self.depth, "order": self.order,
            "weight": self.weight, "turns": self.turns, "cooldown": self.cooldown,
            "decay_minutes": self.decay_minutes, "exclusive_group": self.exclusive_group,
        }


# --------------------------------------------------------------------------- #
# 世界书
# --------------------------------------------------------------------------- #
class Lorebook:
    def __init__(self, name: str, entries: list[LoreEntry]):
        self.name = name
        self.entries = entries

    @classmethod
    def load(cls, path: Path) -> "Lorebook | None":
        try:
            text = path.read_text(encoding="utf-8")
        except Exception as e:
            logger.warning(f"[Lorebook] 读取 {path.name} 失败: {e}")
            return None

        raw_entries = None
        if path.suffix.lower() in (".yaml", ".yml"):
            try:
                data = yaml.safe_load(text) or []
            except Exception as e:
                logger.warning(f"[Lorebook] {path.name} YAML 解析失败: {e}")
                return None
            if isinstance(data, dict):
                raw_entries = data.get("entries") or data.get("lore") or []
            elif isinstance(data, list):
                raw_entries = data
        else:
            try:
                data = json.loads(text)
            except Exception as e:
                logger.warning(f"[Lorebook] {path.name} JSON 解析失败: {e}")
                return None
            raw_entries = data.get("entries") if isinstance(data, dict) else data
            if isinstance(raw_entries, dict):
                raw_entries = [dict(v, uid=k) for k, v in raw_entries.items()
                               if isinstance(v, dict)]

        if not isinstance(raw_entries, list):
            raw_entries = []

        entries = []
        for i, raw in enumerate(raw_entries):
            if isinstance(raw, dict):
                entries.append(LoreEntry.from_any(raw, i))
        if not entries:
            logger.warning(f"[Lorebook] {path.name} 里没有可用条目")
        return cls(path.stem, entries)


# --------------------------------------------------------------------------- #
# 插件
# --------------------------------------------------------------------------- #
@register("astrbot_plugin_lorebook", "DeepSeek",
          "世界书 v2：多规则触发（关键词/cron/定向）+ 位置注入 + LLM 自治待审核",
          "2.0.0")
class LorebookPlugin(Star):
    def __init__(self, context: Context, config: dict | None = None):
        super().__init__(context)
        self.cfg = dict(DEFAULTS)
        if config:
            self.cfg.update({k: v for k, v in config.items() if k in DEFAULTS})
        self.worlds: dict[str, Lorebook] = {}
        self.state: dict[tuple, dict] = {}
        self.pending: list[dict] = []
        self.root = Path(self.cfg["worldsDir"]) if self.cfg["worldsDir"] else Path(__file__).parent / "worlds"
        self.pending_file = self.root / "_pending.json"
        self.reload()
        try:
            from .web_api import LorebookWebApi
        except ImportError:
            from web_api import LorebookWebApi
        try:
            self.web_api = LorebookWebApi(self)
        except Exception as e:
            logger.error(f'[Lorebook] 注册 Web API 失败: {e}')


    # ---------------- 载入 ---------------- #
    def reload(self) -> int:
        self.worlds = {}
        try:
            self.root.mkdir(parents=True, exist_ok=True)
            for f in sorted(self.root.iterdir()):
                if f.suffix.lower() not in (".json", ".yaml", ".yml"):
                    continue
                if f.name.startswith("_"):
                    continue
                book = Lorebook.load(f)
                if book:
                    self.worlds[book.name] = book
        except Exception as e:
            logger.warning(f"[Lorebook] 扫描目录失败: {e}")
        self.load_pending()
        logger.info(f"[Lorebook] 加载 {len(self.worlds)} 本世界书: {list(self.worlds)}")
        return len(self.worlds)

    def load_pending(self) -> None:
        try:
            if self.pending_file.exists():
                self.pending = json.loads(self.pending_file.read_text(encoding="utf-8"))
            else:
                self.pending = []
        except Exception:
            self.pending = []

    def save_pending(self) -> None:
        try:
            self.pending_file.write_text(
                json.dumps(self.pending, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            logger.warning(f"[Lorebook] 保存待审核失败: {e}")

    def books_for(self, group_id: str) -> list[Lorebook]:
        names: list[str] = [str(n) for n in self.cfg["activeWorlds"] if str(n) in self.worlds]
        binding = self.cfg["groupBindings"] or {}
        bound = binding.get(str(group_id)) or binding.get("*")
        if bound:
            for n in (bound if isinstance(bound, list) else [bound]):
                if str(n) in self.worlds and str(n) not in names:
                    names.append(str(n))
        return [self.worlds[n] for n in names]

    # ---------------- 匹配 ---------------- #
    @staticmethod
    def match_text(needle: str, hay: str, case_sensitive: bool, whole_word: bool) -> bool:
        if not needle or not hay:
            return False
        if len(needle) > 2 and needle.startswith("/") and needle.rfind("/") > 0:
            body = needle[1:needle.rfind("/")]
            flags_s = needle[needle.rfind("/") + 1:]
            flags = 0
            if "i" in flags_s:
                flags |= re.IGNORECASE
            if "m" in flags_s:
                flags |= re.MULTILINE
            if "s" in flags_s:
                flags |= re.DOTALL
            try:
                return re.search(body, hay, flags) is not None
            except Exception:
                return False
        a = hay if case_sensitive else hay.lower()
        b = needle if case_sensitive else needle.lower()
        if not whole_word:
            return b in a
        idx = 0
        while True:
            i = a.find(b, idx)
            if i < 0:
                return False
            left = a[i - 1] if i > 0 else " "
            j = i + len(b)
            right = a[j] if j < len(a) else " "
            if not left.isalnum() and not right.isalnum():
                return True
            idx = i + 1

    def key_hit(self, entry: LoreEntry, text: str) -> bool:
        cs = bool(self.cfg["caseSensitive"])
        ww = bool(self.cfg["matchWholeWords"])
        patterns = list(entry.keys) + list(entry.regex)
        primary = [k for k in patterns if k.strip()]
        if not primary:
            return False
        if not any(self.match_text(k, text, cs, ww) for k in primary):
            return False
        secondary = [k for k in entry.secondary if k.strip()]
        if not secondary:
            return True
        hits = [self.match_text(k, text, cs, ww) for k in secondary]
        if entry.logic == 0:
            return any(hits)
        if entry.logic == 1:
            return not all(hits)
        if entry.logic == 2:
            return not any(hits)
        return all(hits)

    # ---------------- 触发管线 ---------------- #
    def entry_active(self, entry: LoreEntry, ctx: dict, state: dict) -> bool:
        now = ctx["ts"]

        if entry.disable or not entry.content.strip():
            return False
        if entry.groups and str(ctx["group_id"]) not in [str(g) for g in entry.groups]:
            return False
        if entry.users and str(ctx["user_id"]) not in [str(u) for u in entry.users]:
            return False

        # 持续状态：turns 或 decay 期间直接续命
        if state.get("turns_left", 0) > 0:
            state["turns_left"] -= 1
            return True
        if state.get("active_until", 0) > now:
            return True

        # 冷却
        if state.get("cool_left", 0) > 0:
            state["cool_left"] -= 1
            return False

        fired = False
        if entry.cron:
            win = float(self.cfg["cronWindowSeconds"])
            minute_key = ctx["dt"].strftime("%Y%m%d%H%M")
            if cron_match(entry.cron, ctx["dt"]) and state.get("last_cron") != minute_key:
                if now - state.get("last_fire", 0) >= win:
                    fired = True
                    state["last_cron"] = minute_key
                    state["last_fire"] = now
        elif entry.constant:
            fired = True
        elif self.key_hit(entry, ctx["text"]):
            fired = True

        if not fired:
            return False

        if entry.probability < 100 and entry.template == "chance":
            if random.randint(1, 100) > max(0, entry.probability):
                return False

        if entry.turns > 0:
            state["turns_left"] = entry.turns
        if entry.decay_minutes > 0:
            state["active_until"] = now + entry.decay_minutes * 60
        state["cool_left"] = entry.cooldown
        return True

    def activate(self, books: list[Lorebook], ctx: dict) -> list[LoreEntry]:
        picked: list[LoreEntry] = []
        for book in books:
            for e in book.entries:
                key = (ctx["umo"], book.name, e.uid)
                st = self.state.setdefault(key, {})
                if self.entry_active(e, ctx, st):
                    picked.append(e)

        # 互斥组：同组只留 order 高的
        exclusive: dict[str, LoreEntry] = {}
        final: list[LoreEntry] = []
        for e in picked:
            if not e.exclusive_group:
                final.append(e)
                continue
            cur = exclusive.get(e.exclusive_group)
            if cur is None or (e.order, e.weight) > (cur.order, cur.weight):
                exclusive[e.exclusive_group] = e
        final.extend(exclusive.values())
        final.sort(key=lambda e: (e.order, e.weight), reverse=True)
        return final

    def recursive(self, books: list[Lorebook], ctx: dict, picked: list[LoreEntry]) -> list[LoreEntry]:
        if not self.cfg["recursive"]:
            return picked
        steps = int(self.cfg["maxRecursionSteps"] or 0)
        if steps <= 0:
            return picked
        have = {e.uid for e in picked}
        for _ in range(steps):
            grown = ctx["text"] + NL + NL.join(e.content for e in picked)
            added = []
            for book in books:
                for e in book.entries:
                    if e.uid in have or e.constant or e.cron:
                        continue
                    if self.key_hit(e, grown):
                        have.add(e.uid)
                        added.append(e)
            if not added:
                break
            picked = picked + added
        picked.sort(key=lambda e: (e.order, e.weight), reverse=True)
        return picked

    # ---------------- 注入 ---------------- #
    def assemble(self, picked: list[LoreEntry]):
        budget = int(self.cfg["budgetChars"])
        head, tail, deep = [], [], []
        used = 0
        for e in picked:
            block = e.content.strip()
            if used + len(block) > budget:
                if self.cfg["debugLog"]:
                    logger.info(f"[Lorebook] 预算用尽，跳过 {e.label}")
                continue
            used += len(block)
            if e.position in (0, 2):
                head.append(block)
            elif e.position in (1, 3):
                tail.append(block)
            else:
                deep.append((max(1, e.depth), block))
        return NL.join(head), NL.join(tail), deep

    @filter.on_llm_request(priority=500)
    async def inject(self, event: AstrMessageEvent, req):
        group_id = str(event.get_group_id() or "")
        books = self.books_for(group_id)
        if not books:
            return

        contexts = list(getattr(req, "contexts", []) or [])
        depth = int(self.cfg["scanDepth"])
        parts = []
        for msg in contexts[-depth:] if depth > 0 else []:
            c = msg.get("content")
            if isinstance(c, list):
                c = " ".join(str(x.get("text", "")) for x in c if isinstance(x, dict))
            if c:
                parts.append(str(c))
        if getattr(req, "prompt", None):
            parts.append(str(req.prompt))
        text = NL.join(parts)
        if not text.strip():
            return

        ctx = {
            "umo": str(event.unified_msg_origin or ""),
            "group_id": group_id,
            "user_id": str(event.get_sender_id() or ""),
            "text": text,
            "ts": time.time(),
            "dt": datetime.now(),
        }
        picked = self.activate(books, ctx)
        picked = self.recursive(books, ctx, picked)
        if not picked:
            return

        head, tail, deep = self.assemble(picked)
        sys_prompt = req.system_prompt or ""
        if head:
            sys_prompt = head + NL + NL + sys_prompt
        if tail:
            sys_prompt = sys_prompt + NL + NL + tail
        req.system_prompt = sys_prompt

        if deep:
            new_ctx = list(contexts)
            for d, block in deep:
                idx = max(0, len(new_ctx) - d + 1)
                new_ctx.insert(idx, {"role": "system", "content": block})
            req.contexts = new_ctx

        if self.cfg["debugLog"]:
            logger.info(f"[Lorebook] 激活 {len(picked)} 条: {[e.label for e in picked]}")

    # ---------------- LLM 自治（写待审核区） ---------------- #
    @filter.llm_tool(name="worldbook_add_entry")
    async def tool_add_entry(self, event: AstrMessageEvent, name: str, content: str,
                             keys: str = "", template: str = "common") -> str:
        """把一条设定写进世界书的待审核区，管理员批准后才生效。

        Args:
            name(string): 条目标题，例如「我家猫」
            content(string): 要注入的设定内容
            keys(string): 触发关键词，多个用逗号分隔
            template(string): 模板，common/resident/chance/schedule/user/group
        """
        if not self.cfg["selfWriteEnabled"]:
            return "世界书自治写入已关闭。"
        key_list = [k.strip() for k in str(keys or "").replace("，", ",").split(",") if k.strip()]
        item = {
            "name": name.strip()[:60],
            "content": content.strip(),
            "keys": key_list,
            "template": (template or "common").strip().lower(),
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "group_id": str(event.get_group_id() or ""),
            "user_id": str(event.get_sender_id() or ""),
        }
        if item["template"] not in TEMPLATES:
            item["template"] = "common"
        self.pending.append(item)
        self.save_pending()
        return f"已写入待审核区（{len(self.pending)} 条待批），管理员用 /世界书 approve 生效。"

    # ---------------- 命令 ---------------- #
    def _admin(self, event: AstrMessageEvent) -> bool:
        if not self.cfg["adminOnly"]:
            return True
        try:
            return bool(event.is_admin())
        except Exception:
            return False

    @filter.command("世界书")
    async def cmd(self, event: AstrMessageEvent, action: str = "", arg: str = ""):
        """世界书：list / reload / test <文本> / pending / approve / reject / del"""
        act = (action or "").strip().lower()

        if act in ("", "list"):
            gid = str(event.get_group_id() or "")
            bound = (self.cfg["groupBindings"] or {}).get(gid)
            if not self.worlds:
                yield event.plain_result(f"还没有世界书，把 YAML/JSON 丢进 {self.root}")
                return
            lines = []
            for name, book in self.worlds.items():
                on = "✓" if (name in [str(x) for x in self.cfg["activeWorlds"]] or name == bound) else "·"
                kinds = {}
                for e in book.entries:
                    kinds[e.template] = kinds.get(e.template, 0) + 1
                detail = " ".join(f"{k}:{v}" for k, v in kinds.items())
                lines.append(f"{on} {name}（{len(book.entries)} 条｜{detail}）")
            if self.pending:
                lines.append(f"待审核 {len(self.pending)} 条：/世界书 pending")
            yield event.plain_result(NL.join(lines))
            return

        if act == "reload":
            if not self._admin(event):
                yield event.plain_result("只有管理员能重载哦")
                return
            n = self.reload()
            yield event.plain_result(f"重载完成：{n} 本｜{'、'.join(self.worlds) or '空'}")
            return

        if act in ("test", "测试"):
            if not self._admin(event):
                yield event.plain_result("只有管理员能跑测试哦")
                return
            sample = (arg or "").strip()
            if not sample:
                yield event.plain_result("用法：/世界书 test 一段话")
                return
            books = self.books_for(str(event.get_group_id() or ""))
            if not books:
                yield event.plain_result("本群还没启用世界书")
                return
            ctx = {"umo": "test", "group_id": str(event.get_group_id() or ""),
                   "user_id": str(event.get_sender_id() or ""), "text": sample,
                   "ts": time.time(), "dt": datetime.now()}
            hit = self.activate(books, ctx)
            if not hit:
                yield event.plain_result("没有条目被激活")
                return
            yield event.plain_result(NL.join(
                f"{e.template}｜{e.label}｜order={e.order} pos={e.position}" for e in hit))
            return

        if act == "pending":
            if not self.pending:
                yield event.plain_result("待审核区是空的")
                return
            lines = []
            for i, p in enumerate(self.pending[:15]):
                lines.append(f"{i}. [{p.get('template')}] {p.get('name')}｜keys={p.get('keys')}")
            if len(self.pending) > 15:
                lines.append(f"...还有 {len(self.pending) - 15} 条")
            lines.append("用 /世界书 approve <序号> 或 approve all")
            yield event.plain_result(NL.join(lines))
            return

        if act == "approve":
            if not self._admin(event):
                yield event.plain_result("只有管理员能批准哦")
                return
            if not self.pending:
                yield event.plain_result("待审核区是空的")
                return
            if arg.strip().lower() in ("all", "全部"):
                idxs = list(range(len(self.pending)))
            else:
                try:
                    idxs = [int(x) for x in arg.replace("，", ",").split(",") if x.strip()]
                except ValueError:
                    yield event.plain_result("序号要填数字，或者 all")
                    return
            idxs = [i for i in idxs if 0 <= i < len(self.pending)]
            if not idxs:
                yield event.plain_result("序号超出范围")
                return
            approved = [self.pending[i] for i in idxs]
            self.pending = [p for i, p in enumerate(self.pending) if i not in idxs]
            self.save_pending()
            added = self._append_to_file(approved)
            yield event.plain_result(f"已批准 {added} 条，写入 auto.yaml 并生效")
            return

        if act == "reject":
            if not self._admin(event):
                yield event.plain_result("只有管理员能驳回哦")
                return
            if arg.strip().lower() in ("all", "全部"):
                n = len(self.pending)
                self.pending = []
                self.save_pending()
                yield event.plain_result(f"已清空 {n} 条待审核")
                return
            try:
                i = int(arg.strip())
            except ValueError:
                yield event.plain_result("用法：/世界书 reject <序号>")
                return
            if 0 <= i < len(self.pending):
                self.pending.pop(i)
                self.save_pending()
                yield event.plain_result("已驳回")
            else:
                yield event.plain_result("序号超出范围")
            return

        yield event.plain_result("用法：/世界书 list|reload|test|pending|approve|reject")

    def _append_to_file(self, items: list[dict]) -> int:
        """把批准的条目追加到 auto.yaml，然后重载"""
        path = self.root / "auto.yaml"
        data = []
        if path.exists():
            try:
                loaded = yaml.safe_load(path.read_text(encoding="utf-8")) or []
                if isinstance(loaded, list):
                    data = loaded
                elif isinstance(loaded, dict):
                    data = loaded.get("entries") or []
            except Exception:
                data = []
        for it in items:
            data.append({
                "name": it.get("name"),
                "template": it.get("template", "common"),
                "content": it.get("content"),
                "keys": it.get("keys") or [],
                "order": 80,
                "position": "at_depth",
                "depth": 3,
            })
        try:
            path.write_text(
                yaml.safe_dump(data, allow_unicode=True, sort_keys=False, width=120),
                encoding="utf-8")
        except Exception as e:
            logger.warning(f"[Lorebook] 写入 auto.yaml 失败: {e}")
            return 0
        self.reload()
        if "auto" not in [str(x) for x in self.cfg["activeWorlds"]]:
            logger.info("[Lorebook] 提示：auto 未在 activeWorlds 里，需手动启用")
        return len(items)

    async def terminate(self):
        if hasattr(self, "web_api"):
            self.web_api.unregister()
