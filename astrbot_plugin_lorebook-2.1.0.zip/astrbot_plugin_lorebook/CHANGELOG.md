# 更新日志

## 2.1.0
- 新增 **WebUI 管理台**（`pages/lorebookManage`）：书库列表、条目编辑、统计面板
- 新增 **快捷导入**：拖拽或粘贴 `.json` / `.yaml`，兼容酒馆 World Info JSON，支持合并与替换
- 新增 **导出**：按 YAML / JSON 导出当前世界书
- 新增世界书管理：新建、重命名、复制、删除、一键启用
- 新增条目操作：复制、跨书移动、启用停用
- 条目编辑覆盖全部字段：次要关键词、匹配逻辑、正则、概率、cron、定向用户群、位置 / 深度 / 次序 / 权重、互斥分组、turns / cooldown / decay
- 新增设置页：`activeWorlds`、群组绑定、扫描深度、字符预算、递归、大小写、全词匹配、自治开关
- 新增待审核审批流管理：批准到指定世界书或一键驳回
- Web API 与页面注册兼容 AstrBot `>= 4.16`

## 2.0.0
- 重构为四层结构：存储模型 / 触发管线 / 自治待审核 / 注入
- 统一 `LoreEntry` 抽象，YAML 与酒馆 JSON 混放
- 6 种模板：common / resident / chance / schedule / user / group
- 状态机：`turns` / `cooldown` / `decay_minutes` / `exclusive_group`
- LLM 工具 `worldbook_add_entry`，写入前必须人工批准
