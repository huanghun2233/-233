# 世界书（astrbot_plugin_lorebook）

给聊天机器人补上「模型不知道的私有事实」——人物、地点、习惯、正在发生的事。
关键词 / 正则 / cron / 定向用户群多源触发，按位置与深度注入上下文，并提供 WebUI 管理台。

- 插件版本：2.1.0
- 适配 AstrBot：`>= 4.16`（使用插件页面与 `register_web_api`）
- 依赖：`PyYAML >= 6.0`

---

## 功能一览

### 触发
- **关键词**：主词 + 次要词，四种逻辑（任一 / 全部 / 非任一 / 非全部）
- **正则**：`/角色名|称呼/i` 形式直接写在关键词或正则字段里
- **cron**：5 段表达式定时触发，配合 `cronWindowSeconds` 去重
- **定向**：按用户 ID、群号生效
- **常驻**：每轮都注入
- **概率**：命中后按百分比掷骰

### 注入
- `position`：system 前置 / 后置、AN 顶部 / 底部、按深度、EM 顶部 / 底部
- `depth`、`order`、`weight` 控制插入位置与排序
- `turns` 持续轮数、`cooldown` 冷却轮数、`decay_minutes` 时间衰减
- `exclusive_group` 互斥组，同组只取 order 最高的一条
- 全局字符预算 `budgetChars`，超出按预算截断

### 存储
- **YAML 为主**（多行中文无需转义），同时兼容**酒馆 World Info JSON**，两种格式可混放
- 6 种模板只是字段语法糖：`common` / `resident` / `chance` / `schedule` / `user` / `group`

### LLM 自治
内置工具 `worldbook_add_entry(name, content, keys, template)`。
模型可在对话中沉淀记忆，但**只进待审核区**，管理员批准后才写盘并热重载——自治必须有闸门。

### WebUI 管理台
插件详情页 →「世界书管理」：
- 左侧书库、统计与待审核入口
- 条目列表支持搜索与模板筛选
- 完整字段编辑：关键词、次要词、逻辑、正则、概率、cron、定向、位置、深度、次序、权重、互斥组、状态机
- **快捷导入**：拖拽 `.json` / `.yaml`，或直接粘贴；合并（同名覆盖）与替换两种模式
- 导出、复制、重命名、删除世界书；单条目复制、移动、启用停用
- 设置页：启用书、群组绑定、扫描深度、字符预算、递归、大小写、全词匹配、自治开关

---

## 安装

1. 把 `astrbot_plugin_lorebook` 整个文件夹放进 `data/plugins/`。
2. 在 AstrBot 面板启用插件（会自动安装 `PyYAML`）。
3. 打开插件详情页 →「世界书管理」，即可在网页里建书、写条目或导入现成世界书。

手动部署时目录结构应如上：`main.py`、`web_api.py`、`_conf_schema.json`、`pages/`、`worlds/` 同级。

---

## 配置文件

| 配置项 | 默认 | 说明 |
|---|---|---|
| `worldsDir` | 空 | 世界书目录，留空用插件自带 `worlds/` |
| `activeWorlds` | `[]` | 全局启用的书（不含后缀），也可在 WebUI 勾选 |
| `groupBindings` | `{}` | `{"群号": ["书A"]}`，`*` 为全局兜底 |
| `scanDepth` | 4 | 扫描最近几条消息作为触发文本 |
| `budgetChars` | 2000 | 注入字符预算 |
| `caseSensitive` | false | 关键词区分大小写 |
| `matchWholeWords` | false | 整词匹配 |
| `recursive` | false | 是否递归扫描已被注入内容 |
| `maxRecursionSteps` | 0 | 递归层数上限 |
| `cronWindowSeconds` | 90 | cron 命中后的去重窗口 |
| `selfWriteEnabled` | true | 允许 LLM 写入待审核区 |
| `adminOnly` | true | 重载 / 测试 / 审批仅管理员 |
| `debugLog` | false | 输出匹配调试日志 |

---

## 条目字段

```yaml
- uid: 1
  name: 角色：守塔人老陈
  template: common          # common/resident/chance/schedule/user/group
  content: |                # 真正被注入的文本
    【角色】老陈，六十岁，右手有旧伤。
  keys: [灯塔, 守塔人]       # 主关键词
  secondary: [晚上, 夜]      # 次要关键词
  logic: any                # any / all / not_any / not_all
  regex: []
  constant: false           # 常驻注入
  probability: 100          # 命中后触发概率 %
  cron: ""                  # 如 "30 7 * * *"
  users: []                 # 定向用户
  groups: []                # 定向群
  position: at_depth        # before/after/an_top/an_bottom/at_depth/em_top/em_bottom
  depth: 3
  order: 120
  weight: 1.0
  turns: 0                  # 触发后持续轮数
  cooldown: 0               # 冷却轮数
  decay_minutes: 0
  exclusive_group: ""
  disable: false
```

酒馆 v2 字段（`key` / `keysecondary` / `comment` / `selectiveLogic` / `disable` 等）会被自动映射。

---

## 指令

| 指令 | 说明 |
|---|---|
| `/世界书 list` | 列出已载入的世界书与条目数 |
| `/世界书 reload` | 重新扫描目录（管理员） |
| `/世界书 test <文本>` | 用一段文本模拟触发，检查命中情况 |
| `/世界书 pending` | 查看待审核条目 |
| `/世界书 approve <序号>` / `approve all` | 批准写入 `auto.yaml`（管理员） |
| `/世界书 reject <序号>` / `reject all` | 驳回（管理员） |

---

## 许可

MIT License，见 `LICENSE`。
