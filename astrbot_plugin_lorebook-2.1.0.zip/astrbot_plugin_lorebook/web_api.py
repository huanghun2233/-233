"""Lorebook Admin Web API —— 供 AstrBot Dashboard 插件页面调用的后端。

路由统一挂载在 /{plugin_name}/...，由 Context.register_web_api 注册，
Dashboard 的 /plugins/extensions/... 会转发到这里。
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

import yaml
from quart import jsonify, request

from astrbot.api import logger

BOOK_EXTS = (".yaml", ".yml", ".json")
POSITION_LABELS = {
    0: "前置 system", 1: "后置 system", 2: "AN 顶部", 3: "AN 底部",
    4: "按深度", 5: "EM 顶部", 6: "EM 底部",
}


def _lore_entry_cls():
    """兼容包内相对导入与直接模块导入两种加载方式。"""
    try:
        from .main import LoreEntry
    except ImportError:
        from main import LoreEntry
    return LoreEntry


def _entry_to_raw(e) -> dict:
    """把 LoreEntry 序列化成落盘用的完整字典。"""
    return {
        "uid": e.uid,
        "name": e.name,
        "template": e.template,
        "content": e.content,
        "keys": list(e.keys),
        "secondary": list(e.secondary),
        "logic": e.logic,
        "regex": list(e.regex),
        "constant": bool(e.constant),
        "probability": e.probability,
        "cron": e.cron,
        "users": list(e.users),
        "groups": list(e.groups),
        "position": e.position,
        "depth": e.depth,
        "order": e.order,
        "weight": e.weight,
        "turns": e.turns,
        "cooldown": e.cooldown,
        "decay_minutes": e.decay_minutes,
        "exclusive_group": e.exclusive_group,
        "disable": bool(e.disable),
    }


def _parse_import_text(text: str, fmt: str) -> list[dict]:
    """把导入文本解析成原始条目字典列表，兼容 YAML 列表与酒馆 v2 JSON。"""
    text = (text or "").strip()
    if not text:
        raise ValueError("导入内容为空")

    data: Any = None
    if fmt == "json":
        data = json.loads(text)
    else:
        try:
            data = yaml.safe_load(text)
        except Exception:
            data = json.loads(text)

    if isinstance(data, dict):
        # 酒馆 v2：{"entries": {"0": {...}}}
        for key in ("entries", "lore", "world_info", "data"):
            if key in data:
                data = data[key]
                break
        else:
            # 单个条目对象
            data = [data]

    if isinstance(data, dict):
        raw = []
        for k, v in data.items():
            if isinstance(v, dict):
                item = dict(v)
                item.setdefault("uid", k)
                raw.append(item)
        data = raw

    if not isinstance(data, list):
        raise ValueError("无法识别的世界书格式")

    entries = [x for x in data if isinstance(x, dict)]
    if not entries:
        raise ValueError("没有解析出任何条目")
    return entries


class LorebookWebApi:
    def __init__(self, plugin: Any):
        self.plugin = plugin
        self.context = plugin.context
        self.plugin_name = "astrbot_plugin_lorebook"
        self.config_path = (
            Path(__file__).resolve().parents[2]
            / "config"
            / "astrbot_plugin_lorebook_config.json"
        )
        self._registered_routes: list[tuple[str, object, tuple[str, ...]]] = []
        self._register()

    # ------------------------------------------------------------------ #
    # 注册
    # ------------------------------------------------------------------ #
    def _register(self) -> None:
        routes = [
            ("books", self.list_books, ["GET"], "列出所有世界书与条目"),
            ("book/export", self.export_book, ["GET"], "导出世界书原文"),
            ("book/create", self.create_book, ["POST"], "新建世界书"),
            ("book/delete", self.delete_book, ["POST"], "删除世界书"),
            ("book/rename", self.rename_book, ["POST"], "重命名世界书"),
            ("book/copy", self.copy_book, ["POST"], "复制世界书"),
            ("book/import", self.import_book, ["POST"], "导入世界书内容"),
            ("book/activate", self.activate_book, ["POST"], "启用或停用世界书"),
            ("entry/save", self.save_entry, ["POST"], "保存条目"),
            ("entry/delete", self.delete_entry, ["POST"], "删除条目"),
            ("entry/duplicate", self.duplicate_entry, ["POST"], "复制条目"),
            ("entry/toggle", self.toggle_entry, ["POST"], "启用或停用条目"),
            ("entry/move", self.move_entry, ["POST"], "移动条目到其它世界书"),
            ("pending", self.list_pending, ["GET"], "列出待审核条目"),
            ("pending/approve", self.approve_pending, ["POST"], "批准待审核条目"),
            ("pending/reject", self.reject_pending, ["POST"], "驳回待审核条目"),
            ("pending/clear", self.clear_pending, ["POST"], "清空待审核区"),
            ("settings", self.get_settings, ["GET"], "读取插件设置"),
            ("settings/save", self.save_settings, ["POST"], "保存插件设置"),
        ]
        for path, handler, methods, desc in routes:
            route = f"/{self.plugin_name}/{path}"
            self.context.register_web_api(route, handler, methods, desc)
            self._registered_routes.append((route, handler, tuple(methods)))
        logger.info(f"[Lorebook] 已注册 {len(routes)} 个管理接口")

    def unregister(self) -> None:
        registry = getattr(self.context, "registered_web_apis", None)
        if not isinstance(registry, list):
            return

        def owned(reg):
            if not isinstance(reg, tuple) or len(reg) < 3:
                return False
            r, h, m = reg[:3]
            return any(
                r == oroute and h is ohandler and tuple(m) == omethods
                for oroute, ohandler, omethods in self._registered_routes
            )

        registry[:] = [r for r in registry if not owned(r)]
        self._registered_routes.clear()

    # ------------------------------------------------------------------ #
    # 工具
    # ------------------------------------------------------------------ #
    @staticmethod
    def _err(message: str, code: int = 400):
        return jsonify({"success": False, "error": message}), code

    async def _body(self) -> dict:
        try:
            data = await request.get_json(force=True, silent=True)
        except Exception:
            data = None
        return data if isinstance(data, dict) else {}

    def _find_book_path(self, name: str) -> Path | None:
        for ext in BOOK_EXTS:
            p = self.plugin.root / f"{name}{ext}"
            if p.exists():
                return p
        return None

    def _write_book(self, name: str, entries: list, fmt: str = "yaml") -> Path:
        """按内存中的条目重写世界书文件。返回文件路径。"""
        path = self._find_book_path(name)
        if path is None:
            path = self.plugin.root / f"{name}.{fmt if fmt in ('json', 'yaml') else 'yaml'}"
        payload = [_entry_to_raw(e) for e in entries]
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.suffix.lower() == ".json":
            path.write_text(
                json.dumps({"entries": payload}, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        else:
            path.write_text(
                yaml.safe_dump(payload, allow_unicode=True, sort_keys=False, width=120),
                encoding="utf-8",
            )
        return path

    def _book_format(self, name: str) -> str:
        path = self._find_book_path(name)
        if path is None:
            return "yaml"
        return "json" if path.suffix.lower() == ".json" else "yaml"

    def _book_info(self, name: str):
        book = self.plugin.worlds.get(name)
        if book is None:
            return None
        active = [str(x) for x in (self.plugin.cfg.get("activeWorlds") or [])]
        bound_groups = [
            gid
            for gid, val in (self.plugin.cfg.get("groupBindings") or {}).items()
            if name in ([val] if isinstance(val, str) else list(val or []))
        ]
        return {
            "name": name,
            "filename": self._find_book_path(name).name if self._find_book_path(name) else name,
            "format": self._book_format(name),
            "active": name in active,
            "bound_groups": bound_groups,
            "count": len(book.entries),
            "enabled_count": len([e for e in book.entries if not e.disable]),
            "entries": [
                dict(
                    _entry_to_raw(e),
                    position_label=POSITION_LABELS.get(int(e.position), str(e.position)),
                    label=e.label,
                )
                for e in book.entries
            ],
        }

    def _save_cfg(self, patch: dict) -> None:
        cfg = self.plugin.cfg
        for k, v in patch.items():
            if k in cfg:
                cfg[k] = v
        self.plugin.root = (
            Path(cfg["worldsDir"]) if cfg.get("worldsDir") else Path(__file__).resolve().parent / "worlds"
        )
        self.plugin.pending_file = self.plugin.root / "_pending.json"
        try:
            exists = self.config_path.exists()
            raw = self.config_path.read_text(encoding="utf-8-sig") if exists else "{}"
            data = json.loads(raw or "{}")
            data.update({k: cfg[k] for k in cfg})
            self.config_path.write_text(
                json.dumps(data, ensure_ascii=False, indent=4), encoding="utf-8"
            )
        except Exception as exc:
            logger.warning(f"[Lorebook] 写入插件配置失败: {exc}")

    # ------------------------------------------------------------------ #
    # 世界书
    # ------------------------------------------------------------------ #
    async def list_books(self):
        try:
            self.plugin.reload()
            books = {}
            for name in self.plugin.worlds:
                info = self._book_info(name)
                if info:
                    books[name] = info
            files = sorted(
                p.stem for p in self.plugin.root.glob("*")
                if p.suffix.lower() in BOOK_EXTS and not p.name.startswith("_")
            )
            return jsonify(
                {
                    "success": True,
                    "books": books,
                    "files": files,
                    "broken": [f for f in files if f not in books],
                    "pending_count": len(self.plugin.pending),
                    "stats": {
                        "books": len(books),
                        "entries": sum(b["count"] for b in books.values()),
                        "active": sum(1 for b in books.values() if b["active"]),
                        "pending": len(self.plugin.pending),
                    },
                }
            )
        except Exception as exc:
            logger.error(f"[Lorebook] 读取世界书失败: {exc}")
            return self._err(str(exc), 500)

    async def export_book(self):
        try:
            name = (request.args.get("name") or "").strip()
            fmt = (request.args.get("format") or "yaml").lower()
            book = self.plugin.worlds.get(name)
            if book is None:
                return self._err("世界书不存在", 404)
            payload = [_entry_to_raw(e) for e in book.entries]
            if fmt == "json":
                content = json.dumps({"entries": payload}, ensure_ascii=False, indent=2)
                filename = f"{name}.json"
            else:
                content = yaml.safe_dump(
                    payload, allow_unicode=True, sort_keys=False, width=120
                )
                filename = f"{name}.yaml"
            return jsonify({"success": True, "filename": filename, "content": content})
        except Exception as exc:
            return self._err(str(exc), 500)

    async def create_book(self):
        try:
            data = await self._body()
            name = str(data.get("name") or "").strip()
            fmt = str(data.get("format") or "yaml").lower()
            if not name:
                return self._err("世界书名称不能为空")
            if not re.fullmatch(r"[\w\-\u4e00-\u9fa5]+", name):
                return self._err("名称只能包含字母、数字、下划线、短横线和中文")
            if self._find_book_path(name):
                return self._err("同名世界书已存在")
            ext = "json" if fmt == "json" else "yaml"
            path = self.plugin.root / f"{name}.{ext}"
            path.parent.mkdir(parents=True, exist_ok=True)
            if ext == "json":
                path.write_text(json.dumps({"entries": []}, ensure_ascii=False, indent=2), encoding="utf-8")
            else:
                path.write_text("# 新建世界书\n[]\n", encoding="utf-8")
            self.plugin.reload()
            return jsonify({"success": True, "message": f"已创建 {path.name}", "name": name})
        except Exception as exc:
            return self._err(str(exc), 500)

    async def delete_book(self):
        try:
            data = await self._body()
            name = str(data.get("name") or "").strip()
            path = self._find_book_path(name)
            if path is None:
                return self._err("世界书不存在", 404)
            path.unlink()
            active = [str(x) for x in (self.plugin.cfg.get("activeWorlds") or [])]
            if name in active:
                active.remove(name)
                self._save_cfg({"activeWorlds": active})
            self.plugin.reload()
            return jsonify({"success": True, "message": "已删除世界书"})
        except Exception as exc:
            return self._err(str(exc), 500)

    async def rename_book(self):
        try:
            data = await self._body()
            name = str(data.get("name") or "").strip()
            new_name = str(data.get("new_name") or "").strip()
            if not name or not new_name:
                return self._err("名称不能为空")
            path = self._find_book_path(name)
            if path is None:
                return self._err("世界书不存在", 404)
            if self._find_book_path(new_name):
                return self._err("目标名称已存在")
            path.rename(path.with_name(f"{new_name}{path.suffix}"))
            active = [str(x) for x in (self.plugin.cfg.get("activeWorlds") or [])]
            if name in active:
                active = [new_name if x == name else x for x in active]
                self._save_cfg({"activeWorlds": active})
            bindings = dict(self.plugin.cfg.get("groupBindings") or {})
            changed = False
            for gid, val in bindings.items():
                vals = [val] if isinstance(val, str) else list(val or [])
                if name in vals:
                    bindings[gid] = [new_name if x == name else x for x in vals]
                    changed = True
            if changed:
                self._save_cfg({"groupBindings": bindings})
            self.plugin.reload()
            return jsonify({"success": True, "message": f"已重命名为 {new_name}", "name": new_name})
        except Exception as exc:
            return self._err(str(exc), 500)

    async def copy_book(self):
        try:
            data = await self._body()
            name = str(data.get("name") or "").strip()
            new_name = str(data.get("new_name") or "").strip()
            book = self.plugin.worlds.get(name)
            if book is None:
                return self._err("世界书不存在", 404)
            if not new_name:
                return self._err("新名称不能为空")
            if self._find_book_path(new_name):
                return self._err("目标名称已存在")
            path = self._write_book(new_name, book.entries, self._book_format(name))
            self.plugin.reload()
            return jsonify({"success": True, "message": f"已复制为 {path.name}", "name": new_name})
        except Exception as exc:
            return self._err(str(exc), 500)

    async def import_book(self):
        try:
            data = await self._body()
            name = str(data.get("name") or "").strip()
            raw_text = data.get("text") or ""
            fmt = str(data.get("format") or "yaml").lower()
            mode = str(data.get("mode") or "merge").lower()
            if not name:
                return self._err("请填写世界书名称")

            raw_entries = _parse_import_text(raw_text, fmt)
            LoreEntry = _lore_entry_cls()

            existing = []
            if mode == "merge":
                book = self.plugin.worlds.get(name)
                if book:
                    existing = list(book.entries)
            base_uid = max([int(e.uid) for e in existing] or [0]) + 1
            imported = []
            for i, raw in enumerate(raw_entries):
                try:
                    imported.append(LoreEntry.from_any(raw, base_uid + i))
                except Exception as exc:
                    logger.warning(f"[Lorebook] 跳过无法解析的条目: {exc}")
            if not imported:
                return self._err("没有可导入的有效条目")

            if mode == "replace":
                entries = imported
            else:
                # 合并时按标题去重，后导入的覆盖同名条目
                by_name = {e.name: e for e in existing if e.name}
                merged = []
                for e in existing:
                    if e.name and e.name in {x.name for x in imported if x.name}:
                        continue
                    merged.append(e)
                merged.extend(imported)
                entries = merged

            path = self._write_book(name, entries, fmt)
            self.plugin.reload()
            return jsonify(
                {
                    "success": True,
                    "message": f"已导入 {len(imported)} 条到 {path.name}",
                    "imported": len(imported),
                    "total": len(entries),
                    "name": name,
                }
            )
        except Exception as exc:
            return self._err(str(exc), 500)

    async def activate_book(self):
        try:
            data = await self._body()
            name = str(data.get("name") or "").strip()
            active = bool(data.get("active"))
            if name not in self.plugin.worlds:
                return self._err("世界书不存在", 404)
            current = [str(x) for x in (self.plugin.cfg.get("activeWorlds") or [])]
            if active and name not in current:
                current.append(name)
            if not active and name in current:
                current.remove(name)
            self._save_cfg({"activeWorlds": current})
            return jsonify({"success": True, "active_worlds": current})
        except Exception as exc:
            return self._err(str(exc), 500)

    # ------------------------------------------------------------------ #
    # 条目
    # ------------------------------------------------------------------ #
    async def save_entry(self):
        try:
            data = await self._body()
            book_name = str(data.get("book") or data.get("book_name") or "").strip()
            raw = data.get("entry") or {}
            book = self.plugin.worlds.get(book_name)
            if book is None:
                return self._err("世界书不存在", 404)
            LoreEntry = _lore_entry_cls()

            uid = raw.get("uid")
            target = None
            if uid is not None:
                for e in book.entries:
                    if str(e.uid) == str(uid):
                        target = e
                        break
            if target is None:
                max_uid = max([int(e.uid) for e in book.entries] or [0])
                raw = dict(raw)
                raw["uid"] = max_uid + 1
                target = LoreEntry.from_any(raw, max_uid + 1)
                book.entries.append(target)
                created = True
            else:
                raw = dict(raw)
                raw["uid"] = target.uid
                merged = LoreEntry.from_any(raw, target.uid)
                merged.source = target.source
                idx = book.entries.index(target)
                book.entries[idx] = merged
                target = merged
                created = False

            if not target.name:
                target.name = (target.keys[0] if target.keys else f"条目 {target.uid}")
            self._write_book(book_name, book.entries, self._book_format(book_name))
            self.plugin.reload()
            return jsonify(
                {
                    "success": True,
                    "message": "已保存条目" if not created else "已新建条目",
                    "uid": target.uid,
                    "entry": _entry_to_raw(target),
                }
            )
        except Exception as exc:
            logger.error(f"[Lorebook] 保存条目失败: {exc}")
            return self._err(str(exc), 500)

    async def delete_entry(self):
        try:
            data = await self._body()
            book_name = str(data.get("book") or "").strip()
            uid = data.get("uid")
            book = self.plugin.worlds.get(book_name)
            if book is None:
                return self._err("世界书不存在", 404)
            before = len(book.entries)
            book.entries = [e for e in book.entries if str(e.uid) != str(uid)]
            if len(book.entries) == before:
                return self._err("条目不存在", 404)
            self._write_book(book_name, book.entries, self._book_format(book_name))
            self.plugin.reload()
            return jsonify({"success": True, "message": "已删除条目"})
        except Exception as exc:
            return self._err(str(exc), 500)

    async def duplicate_entry(self):
        try:
            data = await self._body()
            book_name = str(data.get("book") or "").strip()
            uid = data.get("uid")
            book = self.plugin.worlds.get(book_name)
            if book is None:
                return self._err("世界书不存在", 404)
            LoreEntry = _lore_entry_cls()

            src = next((e for e in book.entries if str(e.uid) == str(uid)), None)
            if src is None:
                return self._err("条目不存在", 404)
            raw = _entry_to_raw(src)
            new_uid = max([int(e.uid) for e in book.entries] or [0]) + 1
            raw["uid"] = new_uid
            raw["name"] = f"{src.name} 副本" if src.name else f"副本 {new_uid}"
            book.entries.append(LoreEntry.from_any(raw, new_uid))
            self._write_book(book_name, book.entries, self._book_format(book_name))
            self.plugin.reload()
            return jsonify({"success": True, "message": "已复制条目", "uid": new_uid})
        except Exception as exc:
            return self._err(str(exc), 500)

    async def toggle_entry(self):
        try:
            data = await self._body()
            book_name = str(data.get("book") or "").strip()
            uid = data.get("uid")
            book = self.plugin.worlds.get(book_name)
            if book is None:
                return self._err("世界书不存在", 404)
            target = next((e for e in book.entries if str(e.uid) == str(uid)), None)
            if target is None:
                return self._err("条目不存在", 404)
            target.disable = bool(data.get("disable", not target.disable))
            self._write_book(book_name, book.entries, self._book_format(book_name))
            self.plugin.reload()
            return jsonify({"success": True, "disable": target.disable})
        except Exception as exc:
            return self._err(str(exc), 500)

    async def move_entry(self):
        try:
            data = await self._body()
            src_name = str(data.get("book") or "").strip()
            dst_name = str(data.get("target") or "").strip()
            uid = data.get("uid")
            src = self.plugin.worlds.get(src_name)
            dst = self.plugin.worlds.get(dst_name)
            if src is None or dst is None:
                return self._err("世界书不存在", 404)
            target = next((e for e in src.entries if str(e.uid) == str(uid)), None)
            if target is None:
                return self._err("条目不存在", 404)
            src.entries.remove(target)
            new_uid = max([int(e.uid) for e in dst.entries] or [0]) + 1
            target.uid = new_uid
            dst.entries.append(target)
            self._write_book(src_name, src.entries, self._book_format(src_name))
            self._write_book(dst_name, dst.entries, self._book_format(dst_name))
            self.plugin.reload()
            return jsonify({"success": True, "message": f"已移动到 {dst_name}"})
        except Exception as exc:
            return self._err(str(exc), 500)

    # ------------------------------------------------------------------ #
    # 待审核
    # ------------------------------------------------------------------ #
    async def list_pending(self):
        try:
            self.plugin.load_pending()
            return jsonify({"success": True, "pending": self.plugin.pending})
        except Exception as exc:
            return self._err(str(exc), 500)

    async def approve_pending(self):
        try:
            data = await self._body()
            idx = data.get("index")
            target_book = str(data.get("book") or "auto").strip()
            pending = self.plugin.pending
            if not isinstance(idx, int) or not (0 <= idx < len(pending)):
                return self._err("序号无效")

            item = pending.pop(idx)
            self.plugin.save_pending()

            LoreEntry = _lore_entry_cls()

            book = self.plugin.worlds.get(target_book)
            entries = list(book.entries) if book else []
            uid = max([int(e.uid) for e in entries] or [0]) + 1
            item = dict(item)
            item["uid"] = uid
            entries.append(LoreEntry.from_any(item, uid))
            self._write_book(target_book, entries, self._book_format(target_book))
            self.plugin.reload()
            return jsonify({"success": True, "message": f"已写入 {target_book}", "book": target_book})
        except Exception as exc:
            return self._err(str(exc), 500)

    async def reject_pending(self):
        try:
            data = await self._body()
            idx = data.get("index")
            pending = self.plugin.pending
            if not isinstance(idx, int) or not (0 <= idx < len(pending)):
                return self._err("序号无效")
            pending.pop(idx)
            self.plugin.save_pending()
            return jsonify({"success": True, "message": "已驳回"})
        except Exception as exc:
            return self._err(str(exc), 500)

    async def clear_pending(self):
        try:
            n = len(self.plugin.pending)
            self.plugin.pending = []
            self.plugin.save_pending()
            return jsonify({"success": True, "message": f"已清空 {n} 条"})
        except Exception as exc:
            return self._err(str(exc), 500)

    # ------------------------------------------------------------------ #
    # 设置
    # ------------------------------------------------------------------ #
    async def get_settings(self):
        try:
            cfg = self.plugin.cfg
            return jsonify(
                {
                    "success": True,
                    "settings": {
                        k: cfg.get(k)
                        for k in (
                            "worldsDir", "activeWorlds", "groupBindings", "scanDepth",
                            "budgetChars", "caseSensitive", "matchWholeWords", "recursive",
                            "maxRecursionSteps", "cronWindowSeconds", "selfWriteEnabled",
                            "adminOnly", "debugLog",
                        )
                    },
                    "worlds_dir": str(self.plugin.root),
                }
            )
        except Exception as exc:
            return self._err(str(exc), 500)

    async def save_settings(self):
        try:
            data = await self._body()
            patch = data.get("settings") if isinstance(data.get("settings"), dict) else data
            allowed = {
                "activeWorlds", "groupBindings", "scanDepth", "budgetChars",
                "caseSensitive", "matchWholeWords", "recursive", "maxRecursionSteps",
                "cronWindowSeconds", "selfWriteEnabled", "adminOnly", "debugLog",
            }
            clean = {k: v for k, v in (patch or {}).items() if k in allowed}
            if "activeWorlds" in clean:
                clean["activeWorlds"] = [
                    str(x) for x in clean["activeWorlds"] if str(x) in self.plugin.worlds
                ]
            if "groupBindings" in clean:
                bindings = {}
                for gid, val in (clean["groupBindings"] or {}).items():
                    vals = [val] if isinstance(val, str) else list(val or [])
                    vals = [str(x) for x in vals if str(x) in self.plugin.worlds]
                    if vals:
                        bindings[str(gid)] = vals
                clean["groupBindings"] = bindings
            self._save_cfg(clean)
            return jsonify({"success": True, "message": "设置已保存", "settings": clean})
        except Exception as exc:
            return self._err(str(exc), 500)
